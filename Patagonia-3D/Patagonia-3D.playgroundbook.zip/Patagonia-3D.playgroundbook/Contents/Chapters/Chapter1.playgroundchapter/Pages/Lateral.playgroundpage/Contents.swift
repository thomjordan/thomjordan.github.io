//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//

//import UIKit
//import Foundation
//import PlaygroundSupport
//import AVFoundation

//let soundPath = Bundle.main.path(forResource: "bell", ofType: "wav")
//let soundURL  = URL(fileURLWithPath: soundPath!)
//let bellPlayer = try? AVAudioPlayer(contentsOf: soundURL, fileTypeHint: "wav")
//
//bellPlayer?.prepareToPlay()
//bellPlayer?.play()

//#-end-hidden-code
